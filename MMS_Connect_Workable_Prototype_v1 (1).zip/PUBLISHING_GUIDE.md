# Publish the MMS Connect Shared Prototype

This is a static front-end prototype using fictional data only.

## Fastest publishing options

### Netlify Drop
1. Extract the ZIP.
2. Open Netlify Drop in a browser.
3. Drag the entire extracted folder onto the page.
4. Netlify creates a public HTTPS link.

### GitHub Pages
1. Create a new repository.
2. Upload the contents of this folder.
3. Open repository Settings > Pages.
4. Publish from the main branch and root folder.

### Vercel
1. Create a new project from a GitHub repository containing these files.
2. Use no framework preset.
3. Leave the build command blank.
4. Publish the root directory.

## Critical restriction

This prototype does not have a secure backend, authentication, encryption, malware scanning,
audit storage, or database-level authorization. Do not use it for real clients, protected health
information, Social Security numbers, financial records, medical records, or official submissions.
