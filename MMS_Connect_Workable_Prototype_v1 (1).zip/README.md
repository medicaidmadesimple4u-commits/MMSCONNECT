# MMS Connect Workable Prototype v1

Open `index.html` in a modern browser.

Functional features:
- local role-based sign-in;
- persistent browser storage using localStorage;
- create and edit referrals;
- role-scoped cases;
- create and update document requests;
- request-only sensitive document workflow for agencies;
- CSV facility bulk import;
- create and update closed-loop community referrals;
- record official DSS decisions;
- create messages and tasks;
- complete tasks;
- reports and audit activity;
- export demo data to JSON;
- reset demo data.

Important:
This is still a front-end prototype. It is not appropriate for real client data or PHI.
A production version requires secure authentication, encrypted storage, server-side authorization,
malware scanning, audit retention, backups, and legal/compliance review.
