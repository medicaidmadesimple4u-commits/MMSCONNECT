
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const storageKey='mmsConnectWorkablePrototypeV1';

const seed={
  referrals:[
    {id:'REF-1001',client:'Martha Green',program:'Long-Term Care Medicaid',county:'Greene',source:'Legacy Memory Care',assignedAgency:'',status:'Converted',created:'2026-07-08'},
    {id:'REF-1002',client:'James Carter',program:'Special Assistance',county:'Pitt',source:'Hospital Social Worker',assignedAgency:'Community Pantry',status:'Contacted',created:'2026-07-09'},
    {id:'REF-1003',client:'Dorothy Hall',program:'CAP/DA',county:'Lenoir',source:'Family',assignedAgency:'Regional Housing Network',status:'New',created:'2026-07-10'}
  ],
  cases:[
    {id:'CASE-2001',client:'Martha Green',program:'Long-Term Care Medicaid',county:'Greene',facility:'Legacy Memory Care',stage:'Documents',owner:'Lakisha Brown',deadline:'2026-07-16',status:'At Risk'},
    {id:'CASE-2002',client:'James Carter',program:'Special Assistance',county:'Pitt',facility:'',stage:'Decision Review',owner:'Lakisha Brown',deadline:'2026-07-18',status:'Denied'},
    {id:'CASE-2003',client:'Dorothy Hall',program:'CAP/DA',county:'Lenoir',facility:'',stage:'Community Referral',owner:'Lakisha Brown',deadline:'2026-07-20',status:'Open'}
  ],
  documents:[
    {id:'DOC-1',client:'Martha Green',name:'Current bank statements',status:'Missing',due:'2026-07-16',sensitive:true},
    {id:'DOC-2',client:'Martha Green',name:'Facility verification',status:'Accepted',due:'2026-07-12',sensitive:false},
    {id:'DOC-3',client:'James Carter',name:'FL-2',status:'Under review',due:'2026-07-15',sensitive:false}
  ],
  communityReferrals:[
    {id:'CR-1',client:'Martha Green',need:'Transportation',agency:'Lenoir Transit',status:'Accepted',outcome:'Ride scheduled'},
    {id:'CR-2',client:'James Carter',need:'Food Assistance',agency:'Community Pantry',status:'No response',outcome:'Pending'},
    {id:'CR-3',client:'Dorothy Hall',need:'Housing Support',agency:'Regional Housing Network',status:'Declined',outcome:'Rematch needed'}
  ],
  decisions:[
    {id:'DEC-1',client:'Martha Green',program:'Long-Term Care Medicaid',status:'Approved',date:'2026-07-08',reason:'Effective 2026-06-01'},
    {id:'DEC-2',client:'James Carter',program:'Special Assistance',status:'Denied',date:'2026-07-07',reason:'Missing verification'}
  ],
  messages:[
    {id:'MSG-1',from:'Legacy Memory Care',to:'Medicaid Made Simple',subject:'Facility verification uploaded',body:'Fictional message.',date:'2026-07-10',read:false},
    {id:'MSG-2',from:'Community Pantry',to:'Medicaid Made Simple',subject:'Referral received',body:'Intake call scheduled.',date:'2026-07-11',read:true}
  ],
  tasks:[
    {id:'TASK-1',title:'Review Martha Green documents',owner:'Lakisha Brown',due:'2026-07-14',status:'Open'},
    {id:'TASK-2',title:'Follow up with Community Pantry',owner:'Lakisha Brown',due:'2026-07-13',status:'Open'}
  ],
  audit:[]
};

let db=loadDB();
let session={role:'MMS Administrator',org:'Medicaid Made Simple',name:'Demo User'};
let currentModule='dashboard';

function clone(v){return JSON.parse(JSON.stringify(v))}
function loadDB(){try{return JSON.parse(localStorage.getItem(storageKey))||clone(seed)}catch{return clone(seed)}}
function saveDB(){localStorage.setItem(storageKey,JSON.stringify(db))}
function audit(action,detail){db.audit.unshift({time:new Date().toISOString(),actor:session.name,role:session.role,action,detail});saveDB()}
function resetDB(){db=clone(seed);saveDB();toast('Demo data reset.')}
function toast(msg){const t=$('#toast');t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2200)}
function uid(prefix){return `${prefix}-${Math.floor(1000+Math.random()*9000)}`}

const permissions={
  'MMS Administrator':['dashboard','referrals','cases','documents','bulk','community','decisions','messages','tasks','reports','audit'],
  'Facility User':['dashboard','referrals','cases','documents','bulk','messages','tasks'],
  'Hospital/Social Worker':['dashboard','referrals','cases','documents','community','messages','tasks'],
  'Community Agency':['dashboard','community','documents','messages','tasks'],
  'Client/Representative':['dashboard','documents','community','messages','tasks']
};

const labels={
  dashboard:'Dashboard',referrals:'Referrals',cases:'Cases',documents:'Documents',bulk:'Facility Bulk Upload',
  community:'Closed-Loop Referrals',decisions:'DSS Decisions',messages:'Secure Messages',
  tasks:'Tasks',reports:'Reports',audit:'Audit Log'
};

$('#enter-app').onclick=()=>{
  session.role=$('#login-role').value;
  session.org=$('#login-org').value||'Demo Organization';
  session.name=$('#login-name').value||'Demo User';
  $('#login-screen').classList.add('hidden');
  $('#app-screen').classList.remove('hidden');
  $('#user-name').textContent=session.name;
  $('#user-role').textContent=session.role;
  $('#user-org').textContent=session.org;
  buildNav();openModule('dashboard');audit('session_start',session.role);
};
$('#switch-user').onclick=()=>{$('#app-screen').classList.add('hidden');$('#login-screen').classList.remove('hidden')}
$('#reset-demo').onclick=()=>{resetDB()}
$('#export-data').onclick=()=>{
  const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='mms-connect-demo-data.json';a.click();URL.revokeObjectURL(a.href);
  audit('export_demo_data','JSON export');toast('Demo data exported.');
};
$('#modal-close').onclick=closeModal;
$('#modal').onclick=e=>{if(e.target.id==='modal')closeModal()};

function buildNav(){
  const nav=$('#main-nav');nav.innerHTML='';
  permissions[session.role].forEach(m=>{
    const b=document.createElement('button');b.textContent=labels[m];b.dataset.module=m;b.onclick=()=>openModule(m);nav.appendChild(b);
  });
}
function openModule(m){
  if(!permissions[session.role].includes(m)){return showDenied(m)}
  currentModule=m;
  $$('#main-nav button').forEach(b=>b.classList.toggle('active',b.dataset.module===m));
  $('#page-title').textContent=labels[m];
  $('#page-subtitle').textContent=`${session.role} • ${session.org}`;
  render();
}
function showDenied(m){
  $('#content').innerHTML=`<div class="denied-panel"><h2>Access Denied</h2><p>Your role cannot access ${labels[m]||m}.</p><button class="btn" onclick="openModule('dashboard')">Return to dashboard</button></div>`;
  audit('access_denied',m);
}

function scopedCases(){
  if(session.role==='Community Agency') return db.cases.filter(c=>db.communityReferrals.some(r=>r.client===c.client&&r.agency===session.org));
  if(session.role==='Client/Representative') return db.cases.filter(c=>c.client==='Martha Green');
  if(session.role==='Facility User') return db.cases.filter(c=>c.facility===session.org||session.org==='Demo Organization');
  return db.cases;
}
function scopedCommunity(){
  if(session.role==='Community Agency') return db.communityReferrals.filter(r=>r.agency===session.org||session.org==='Demo Organization');
  if(session.role==='Client/Representative') return db.communityReferrals.filter(r=>r.client==='Martha Green');
  return db.communityReferrals;
}
function scopedDocuments(){
  if(session.role==='Community Agency') return db.documents.filter(d=>scopedCommunity().some(r=>r.client===d.client)).map(d=>({...d,name:d.sensitive?'Sensitive document — request access':d.name}));
  if(session.role==='Client/Representative') return db.documents.filter(d=>d.client==='Martha Green');
  return db.documents;
}

function render(){
  const map={dashboard:renderDashboard,referrals:renderReferrals,cases:renderCases,documents:renderDocuments,bulk:renderBulk,community:renderCommunity,decisions:renderDecisions,messages:renderMessages,tasks:renderTasks,reports:renderReports,audit:renderAudit};
  map[currentModule]();
}
function metric(label,value,help){return `<article class="card"><div class="metric-label">${label}</div><div class="metric-value">${value}</div><div class="metric-help">${help}</div></article>`}
function badge(s){const c=/approved|accepted|complete|closed/i.test(s)?'positive':/denied|missing|declined|overdue|risk/i.test(s)?'risk':/pending|review|contacted|new|open|no response/i.test(s)?'caution':'info';return `<span class="status ${c}">${s}</span>`}
function table(headers,rows){
  return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
  <div class="mobile-cards">${rows.map(r=>`<article class="record-card">${r.map((c,i)=>`<p><strong>${headers[i]}:</strong><br>${c}</p>`).join('')}</article>`).join('')}</div>`;
}
function renderDashboard(){
  const cases=scopedCases(),community=scopedCommunity(),docs=scopedDocuments();
  $('#content').innerHTML=`<div class="grid">${metric('Active cases',cases.length,'Visible to your role')}${metric('Documents needed',docs.filter(d=>d.status==='Missing').length,'Outstanding')}${metric('Community referrals',community.length,'Assigned or created')}${metric('Unread messages',db.messages.filter(m=>!m.read).length,'Portal messages')}</div>
  <div style="height:18px"></div><div class="two-col"><section class="card"><h2>Priority work</h2>${table(['Client','Stage','Status','Deadline'],cases.map(c=>[c.client,c.stage,badge(c.status),c.deadline]))}</section>
  <aside class="card"><h2>Quick actions</h2><div class="quick-actions">
  ${permissions[session.role].includes('referrals')?'<button class="btn btn-primary" onclick="newReferral()">Create referral</button>':''}
  ${permissions[session.role].includes('documents')?'<button class="btn" onclick="newDocumentRequest()">Request document</button>':''}
  ${permissions[session.role].includes('community')?'<button class="btn" onclick="newCommunityReferral()">Community referral</button>':''}
  </div></aside></div>`;
}
function renderReferrals(){
  $('#content').innerHTML=`<div class="toolbar"><button class="btn btn-primary" onclick="newReferral()">Create referral</button><input class="search-input" id="ref-search" placeholder="Search referrals"></div>
  <div id="ref-list">${referralTable(db.referrals)}</div>`;
  $('#ref-search').oninput=e=>$('#ref-list').innerHTML=referralTable(db.referrals.filter(r=>JSON.stringify(r).toLowerCase().includes(e.target.value.toLowerCase())));
}
function referralTable(rows){return table(['ID','Client','Program','County','Source','Status','Action'],rows.map(r=>[r.id,r.client,r.program,r.county,r.source,badge(r.status),`<button class="btn" onclick="editReferral('${r.id}')">Edit</button>`]))}
function renderCases(){
  const rows=scopedCases();
  $('#content').innerHTML=table(['ID','Client','Program','Stage','Owner','Deadline','Status'],rows.map(c=>[c.id,c.client,c.program,c.stage,c.owner,c.deadline,badge(c.status)]));
}
function renderDocuments(){
  const rows=scopedDocuments();
  $('#content').innerHTML=`<div class="toolbar"><button class="btn btn-primary" onclick="newDocumentRequest()">Create request</button></div>${table(['Client','Document','Due','Status','Action'],rows.map(d=>[d.client,d.name,d.due,badge(d.status),session.role==='Community Agency'?`<button class="btn" onclick="requestSensitive('${d.id}')">Request access</button>`:`<button class="btn" onclick="updateDocument('${d.id}')">Update</button>`]))}`;
}
function renderBulk(){
  $('#content').innerHTML=`<div class="alert"><strong>Use fictional data only.</strong> CSV columns: First Name, Last Name, County, Program, Facility, Admission Date.</div>
  <div class="two-col"><section class="card"><h2>Import facility referrals</h2><div class="field"><label>CSV file</label><input id="csv-file" type="file" accept=".csv"></div><button class="btn btn-primary" onclick="importCSV()">Validate and import</button></section><aside class="card"><h3>Template</h3><button class="btn" onclick="downloadCSVTemplate()">Download CSV template</button><div id="import-result"></div></aside></div>`;
}
function renderCommunity(){
  const rows=scopedCommunity();
  $('#content').innerHTML=`<div class="toolbar"><button class="btn btn-primary" onclick="newCommunityReferral()">Create referral</button></div>${table(['ID','Client','Need','Agency','Status','Outcome','Action'],rows.map(r=>[r.id,r.client,r.need,r.agency,badge(r.status),r.outcome,`<button class="btn" onclick="updateCommunity('${r.id}')">Update</button>`]))}`;
}
function renderDecisions(){
  $('#content').innerHTML=`<div class="alert"><strong>MMS Connect records official DSS decisions only.</strong> MMS does not determine eligibility.</div><div class="toolbar"><button class="btn btn-primary" onclick="newDecision()">Record official decision</button></div>${table(['Client','Program','Official status','Date','Reason'],db.decisions.map(d=>[d.client,d.program,badge(d.status),d.date,d.reason]))}`;
}
function renderMessages(){
  $('#content').innerHTML=`<div class="toolbar"><button class="btn btn-primary" onclick="newMessage()">New message</button></div>${table(['From','To','Subject','Date','Status'],db.messages.map(m=>[m.from,m.to,m.subject,m.date,m.read?badge('Read'):badge('Unread')]))}`;
}
function renderTasks(){
  $('#content').innerHTML=`<div class="toolbar"><button class="btn btn-primary" onclick="newTask()">New task</button></div>${table(['Task','Owner','Due','Status','Action'],db.tasks.map(t=>[t.title,t.owner,t.due,badge(t.status),`<button class="btn" onclick="completeTask('${t.id}')">Complete</button>`]))}`;
}
function renderReports(){
  const approvals=db.decisions.filter(d=>d.status==='Approved').length,total=db.decisions.length||1;
  $('#content').innerHTML=`<div class="grid">${metric('Approval rate',Math.round(approvals/total*100)+'%','Official DSS decisions')}${metric('Referral conversion',Math.round(db.referrals.filter(r=>r.status==='Converted').length/(db.referrals.length||1)*100)+'%','Converted referrals')}${metric('Closed-loop success',Math.round(db.communityReferrals.filter(r=>/completed|scheduled|received/i.test(r.outcome)).length/(db.communityReferrals.length||1)*100)+'%','Confirmed outcomes')}${metric('Open tasks',db.tasks.filter(t=>t.status!=='Completed').length,'Work queue')}</div>`;
}
function renderAudit(){
  $('#content').innerHTML=table(['Time','Actor','Role','Action','Detail'],db.audit.map(a=>[new Date(a.time).toLocaleString(),a.actor,a.role,a.action,a.detail]));
}

function openModal(title,html){$('#modal-title').textContent=title;$('#modal-body').innerHTML=html;$('#modal').classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden')}
function formValue(id){return document.getElementById(id).value.trim()}

window.newReferral=()=>openModal('Create referral',`<div class="form-grid">
<div class="field"><label>Client name</label><input id="f-client"></div><div class="field"><label>Program</label><select id="f-program"><option>Long-Term Care Medicaid</option><option>Special Assistance</option><option>SAIH</option><option>CAP/DA</option></select></div>
<div class="field"><label>County</label><input id="f-county" value="Lenoir"></div><div class="field"><label>Source</label><input id="f-source" value="${session.org}"></div></div>
<button class="btn btn-primary" onclick="saveReferral()">Create referral</button>`);
window.saveReferral=()=>{const client=formValue('f-client');if(!client)return toast('Client name is required.');db.referrals.unshift({id:uid('REF'),client,program:formValue('f-program'),county:formValue('f-county'),source:formValue('f-source'),assignedAgency:'',status:'New',created:new Date().toISOString().slice(0,10)});saveDB();audit('create_referral',client);closeModal();render();toast('Referral created.')};
window.editReferral=id=>{const r=db.referrals.find(x=>x.id===id);openModal('Edit referral',`<div class="field"><label>Status</label><select id="e-status"><option ${r.status==='New'?'selected':''}>New</option><option ${r.status==='Contacted'?'selected':''}>Contacted</option><option ${r.status==='Converted'?'selected':''}>Converted</option><option>Closed</option></select></div><button class="btn btn-primary" onclick="saveReferralEdit('${id}')">Save</button>`)};
window.saveReferralEdit=id=>{db.referrals.find(x=>x.id===id).status=formValue('e-status');saveDB();audit('update_referral',id);closeModal();render();toast('Referral updated.')};

window.newDocumentRequest=()=>openModal('Create document request',`<div class="form-grid"><div class="field"><label>Client</label><input id="d-client" value="Martha Green"></div><div class="field"><label>Document</label><input id="d-name"></div><div class="field"><label>Due date</label><input id="d-due" type="date"></div><div class="field"><label>Sensitive?</label><select id="d-sensitive"><option value="false">No</option><option value="true">Yes</option></select></div></div><button class="btn btn-primary" onclick="saveDocumentRequest()">Create request</button>`);
window.saveDocumentRequest=()=>{db.documents.unshift({id:uid('DOC'),client:formValue('d-client'),name:formValue('d-name'),status:'Missing',due:formValue('d-due'),sensitive:formValue('d-sensitive')==='true'});saveDB();audit('create_document_request',formValue('d-name'));closeModal();render();toast('Document request created.')};
window.updateDocument=id=>{const d=db.documents.find(x=>x.id===id);d.status=d.status==='Accepted'?'Under review':'Accepted';saveDB();audit('update_document',id);render();toast('Document status updated.')};
window.requestSensitive=id=>{audit('request_sensitive_document',id);toast('Sensitive document request routed for approval.')};

window.newCommunityReferral=()=>openModal('Create community referral',`<div class="form-grid"><div class="field"><label>Client</label><input id="c-client" value="Martha Green"></div><div class="field"><label>Need</label><input id="c-need"></div><div class="field"><label>Agency</label><input id="c-agency" value="${session.org==='Medicaid Made Simple'?'Community Pantry':session.org}"></div></div><button class="btn btn-primary" onclick="saveCommunityReferral()">Create referral</button>`);
window.saveCommunityReferral=()=>{db.communityReferrals.unshift({id:uid('CR'),client:formValue('c-client'),need:formValue('c-need'),agency:formValue('c-agency'),status:'Sent',outcome:'Pending'});saveDB();audit('create_community_referral',formValue('c-client'));closeModal();render();toast('Community referral created.')};
window.updateCommunity=id=>{const r=db.communityReferrals.find(x=>x.id===id);openModal('Update community referral',`<div class="field"><label>Status</label><select id="u-status"><option>Accepted</option><option>Waitlisted</option><option>Declined</option><option>No response</option><option>Completed</option></select></div><div class="field"><label>Outcome</label><input id="u-outcome" value="${r.outcome}"></div><button class="btn btn-primary" onclick="saveCommunityUpdate('${id}')">Save update</button>`)};
window.saveCommunityUpdate=id=>{const r=db.communityReferrals.find(x=>x.id===id);r.status=formValue('u-status');r.outcome=formValue('u-outcome');saveDB();audit('update_community_referral',id);closeModal();render();toast('Referral outcome updated.')};

window.newDecision=()=>openModal('Record official DSS decision',`<div class="form-grid"><div class="field"><label>Client</label><input id="x-client"></div><div class="field"><label>Program</label><input id="x-program"></div><div class="field"><label>Official status</label><select id="x-status"><option>Approved</option><option>Denied</option><option>Pending</option><option>Withdrawn</option></select></div><div class="field"><label>Decision date</label><input id="x-date" type="date"></div><div class="field" style="grid-column:1/-1"><label>Official reason or effective date</label><textarea id="x-reason"></textarea></div></div><button class="btn btn-primary" onclick="saveDecision()">Save official decision</button>`);
window.saveDecision=()=>{db.decisions.unshift({id:uid('DEC'),client:formValue('x-client'),program:formValue('x-program'),status:formValue('x-status'),date:formValue('x-date'),reason:formValue('x-reason')});saveDB();audit('record_dss_decision',formValue('x-client'));closeModal();render();toast('Official DSS decision recorded.')};

window.newMessage=()=>openModal('New secure message',`<div class="field"><label>To</label><input id="m-to"></div><div class="field"><label>Subject</label><input id="m-subject"></div><div class="field"><label>Message</label><textarea id="m-body"></textarea></div><button class="btn btn-primary" onclick="saveMessage()">Send message</button>`);
window.saveMessage=()=>{db.messages.unshift({id:uid('MSG'),from:session.org,to:formValue('m-to'),subject:formValue('m-subject'),body:formValue('m-body'),date:new Date().toISOString().slice(0,10),read:false});saveDB();audit('send_message',formValue('m-to'));closeModal();render();toast('Message sent.')};

window.newTask=()=>openModal('New task',`<div class="field"><label>Task</label><input id="t-title"></div><div class="field"><label>Owner</label><input id="t-owner" value="${session.name}"></div><div class="field"><label>Due</label><input id="t-due" type="date"></div><button class="btn btn-primary" onclick="saveTask()">Create task</button>`);
window.saveTask=()=>{db.tasks.unshift({id:uid('TASK'),title:formValue('t-title'),owner:formValue('t-owner'),due:formValue('t-due'),status:'Open'});saveDB();audit('create_task',formValue('t-title'));closeModal();render();toast('Task created.')};
window.completeTask=id=>{db.tasks.find(x=>x.id===id).status='Completed';saveDB();audit('complete_task',id);render();toast('Task completed.')};

window.downloadCSVTemplate=()=>{const csv='First Name,Last Name,County,Program,Facility,Admission Date\\nHelen,Brooks,Lenoir,Long-Term Care Medicaid,Legacy Memory Care,2026-07-01';const blob=new Blob([csv],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='MMS_Connect_Facility_Referral_Template.csv';a.click();URL.revokeObjectURL(a.href)};
window.importCSV=()=>{
  const f=$('#csv-file').files[0];if(!f)return toast('Choose a CSV file.');
  const reader=new FileReader();reader.onload=()=>{
    const lines=reader.result.split(/\\r?\\n/).filter(Boolean);let imported=0;
    lines.slice(1).forEach(line=>{const [first,last,county,program,facility]=line.split(',').map(s=>s.trim());if(first&&last){db.referrals.unshift({id:uid('REF'),client:`${first} ${last}`,program,county,source:facility,assignedAgency:'',status:'New',created:new Date().toISOString().slice(0,10)});imported++;}});
    saveDB();audit('bulk_import',`${imported} rows`);$('#import-result').innerHTML=`<div class="confirm-panel"><strong>${imported} referrals imported.</strong></div>`;toast('CSV import completed.');
  };reader.readAsText(f);
};
